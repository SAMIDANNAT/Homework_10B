public class SumaMedia{
	public static void main(String args[]){
		int a,b,c,suma;
        float avg;
		System.out.println("Introdu oricare 3 numere ");
		Scanner in = new Scanner(System.in);
		a = in.nextInt();
		b = in.nextInt();
		c = in.nextInt();
		suma=a+b+c;
        avg = (float)((a+b+c)/3);
		System.out.println("Suma este "+suma);
        System.out.println("Media aritmetica este "+avg);
	}
}
